# FallotyXDD Friend — mod para Minecraft Forge 1.20.1

Un amigo con IA (Groq) y voz (Fish Audio) que se une a tu partida unos segundos después de entrar.

## Compilar (necesitas Java 17)
1. Descarga el MDK de Forge **1.20.1-47.3.0** (files.minecraftforge.net) y copia de él a esta carpeta:
   `gradlew`, `gradlew.bat` y la carpeta `gradle/`.
2. En esta carpeta ejecuta:  `./gradlew build`   (Windows: `gradlew build`)
3. El mod queda en `build/libs/falloty-1.0.0.jar` → ponlo en la carpeta `mods` (cliente y servidor).

## API keys (obligatorio Groq, Fish da la voz)
- Groq: https://console.groq.com/keys     Fish Audio: https://fish.audio/app/api-keys
- En el juego: `/falloty groqkey TU_KEY`  y  `/falloty fishkey TU_KEY`  (opcional `/falloty voice ID_DE_VOZ`)
- O edita `config/falloty-common.toml`. En servidores públicos mejor usar el archivo (los comandos quedan en logs).
- Sin key de Groq NO se une (te avisa en el chat). Sin key de Fish habla solo por chat.
- Otros comandos: `/falloty spawn`, `/falloty status`

## Cómo hablarle
Escribe en el chat (o di "falloty ..."). Ejemplos: "construye una casa", "busca minerales", "tala árboles",
"ven", "quédate", "siéntate", "vete a dormir", "dame lo que recogiste", "ataca".
- Click derecho con la mano vacía: sentarlo/levantarlo. Shift + click derecho: te da lo que recogió.
- Click derecho con chocolate: se lo regalas (le encanta, se cura y lo come cuando está herido).

## Chocolate
- Receta (sin forma): 2 cacao + 1 azúcar + 1 cubeta de leche → 4 Chocolates envueltos.
- Click derecho al envuelto: se abre → Chocolate (comible, da velocidad) + Envoltorio.
- Pestaña creativa "FallotyXDD".

## Notas
- El modelo se optimizó (376k → 18.7k triángulos) para que Minecraft lo mueva fluido.
- La casa solo se construye en el Overworld, en terreno natural (no destruye tus construcciones).
- Constantes de ajuste de la mano/herramienta: `FallotyRenderer` (translate/rotación del item).
