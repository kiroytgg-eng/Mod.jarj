package com.falloty.client;

import com.google.gson.*;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;

/** Malla con esqueleto (exportada de FallotyXDD_rigged.glb) con skinning por CPU y animaciones. */
public class FallotyModel {
    private static FallotyModel INSTANCE;
    private static boolean failed;

    public static FallotyModel get() {
        if (INSTANCE == null && !failed) {
            try { INSTANCE = new FallotyModel(); }
            catch (Exception e) { failed = true; LogManager.getLogger("falloty").error("No se pudo cargar el modelo", e); }
        }
        return INSTANCE;
    }

    public static class Pose {
        public final Quaternionf[] r; public final Vector3f[] t;
        Pose(int n) { r = new Quaternionf[n]; t = new Vector3f[n]; for (int i = 0; i < n; i++) { r[i] = new Quaternionf(); t[i] = new Vector3f(); } }
    }

    private static class Track { float[] rt, rv, pt, pv; }
    public static class Anim { public float duration; Track[] tracks; }

    public final int jointCount;
    private final int vc, ic;
    private final float[] pos, nrm, uv, weights;
    private final int[] joints, idx;
    private final int[] parent;
    private final String[] names;
    private final Vector3f[] restT; private final Quaternionf[] restR;
    private final Matrix4f[] ibm, world, skinM;
    private final float[] skinArr;
    private final float[] sp, sn;
    public final Map<String, Anim> anims = new HashMap<>();
    private final Map<String, Integer> nameIdx = new HashMap<>();

    public final Pose idlePose, walkPose, runPose, mixA, mixB, finalPose;

    private FallotyModel() throws Exception {
        ResourceLocation meshRl = new ResourceLocation("falloty", "falloty/falloty_mesh.bin");
        ResourceLocation rigRl = new ResourceLocation("falloty", "falloty/falloty_rig.json");
        byte[] bin;
        try (InputStream in = Minecraft.getInstance().getResourceManager().getResourceOrThrow(meshRl).open()) { bin = in.readAllBytes(); }
        ByteBuffer b = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN);
        b.getInt();
        vc = b.getInt(); ic = b.getInt();
        pos = new float[vc * 3]; nrm = new float[vc * 3]; uv = new float[vc * 2]; weights = new float[vc * 4];
        joints = new int[vc * 4]; idx = new int[ic];
        for (int i = 0; i < pos.length; i++) pos[i] = b.getFloat();
        for (int i = 0; i < nrm.length; i++) nrm[i] = b.getFloat();
        for (int i = 0; i < uv.length; i++) uv[i] = b.getFloat();
        for (int i = 0; i < joints.length; i++) joints[i] = b.get() & 0xFF;
        for (int i = 0; i < weights.length; i++) weights[i] = b.getFloat();
        for (int i = 0; i < ic; i++) idx[i] = b.getInt();
        sp = new float[vc * 3]; sn = new float[vc * 3];

        JsonObject rig;
        try (InputStream in = Minecraft.getInstance().getResourceManager().getResourceOrThrow(rigRl).open()) {
            rig = JsonParser.parseReader(new InputStreamReader(in)).getAsJsonObject();
        }
        JsonArray ja = rig.getAsJsonArray("joints");
        jointCount = ja.size();
        parent = new int[jointCount]; names = new String[jointCount];
        restT = new Vector3f[jointCount]; restR = new Quaternionf[jointCount];
        ibm = new Matrix4f[jointCount]; world = new Matrix4f[jointCount]; skinM = new Matrix4f[jointCount];
        skinArr = new float[jointCount * 16];
        JsonArray ib = rig.getAsJsonArray("ibm");
        for (int i = 0; i < jointCount; i++) {
            JsonObject j = ja.get(i).getAsJsonObject();
            names[i] = j.get("name").getAsString(); nameIdx.put(names[i], i);
            parent[i] = j.get("parent").getAsInt();
            JsonArray t = j.getAsJsonArray("t"), r = j.getAsJsonArray("r");
            restT[i] = new Vector3f(t.get(0).getAsFloat(), t.get(1).getAsFloat(), t.get(2).getAsFloat());
            restR[i] = new Quaternionf(r.get(0).getAsFloat(), r.get(1).getAsFloat(), r.get(2).getAsFloat(), r.get(3).getAsFloat());
            float[] m = new float[16];
            for (int k = 0; k < 16; k++) m[k] = ib.get(i * 16 + k).getAsFloat();
            ibm[i] = new Matrix4f().set(m);
            world[i] = new Matrix4f(); skinM[i] = new Matrix4f();
        }
        JsonObject an = rig.getAsJsonObject("animations");
        for (Map.Entry<String, JsonElement> en : an.entrySet()) {
            JsonObject a = en.getValue().getAsJsonObject();
            Anim anim = new Anim(); anim.duration = a.get("duration").getAsFloat(); anim.tracks = new Track[jointCount];
            for (Map.Entry<String, JsonElement> te : a.getAsJsonObject("tracks").entrySet()) {
                Track tr = new Track(); JsonObject o = te.getValue().getAsJsonObject();
                if (o.has("rot")) { tr.rt = arr(o.getAsJsonObject("rot").getAsJsonArray("t")); tr.rv = arr(o.getAsJsonObject("rot").getAsJsonArray("v")); }
                if (o.has("pos")) { tr.pt = arr(o.getAsJsonObject("pos").getAsJsonArray("t")); tr.pv = arr(o.getAsJsonObject("pos").getAsJsonArray("v")); }
                anim.tracks[Integer.parseInt(te.getKey())] = tr;
            }
            anims.put(en.getKey(), anim);
        }
        idlePose = new Pose(jointCount); walkPose = new Pose(jointCount); runPose = new Pose(jointCount);
        mixA = new Pose(jointCount); mixB = new Pose(jointCount); finalPose = new Pose(jointCount);
    }

    private static float[] arr(JsonArray a) { float[] f = new float[a.size()]; for (int i = 0; i < f.length; i++) f[i] = a.get(i).getAsFloat(); return f; }

    public int joint(String name) { return nameIdx.getOrDefault(name, 0); }

    /** Muestrea una animacion (en bucle) en el tiempo dado. */
    public void sample(String name, float time, Pose out) {
        Anim a = anims.get(name);
        for (int j = 0; j < jointCount; j++) {
            out.r[j].set(restR[j]); out.t[j].set(restT[j]);
            if (a == null || a.tracks[j] == null) continue;
            Track tr = a.tracks[j];
            float tm = a.duration > 0 ? time % a.duration : 0;
            if (tr.rt != null) {
                int i = seg(tr.rt, tm);
                float f = i + 1 < tr.rt.length ? (tm - tr.rt[i]) / Math.max(1e-6f, tr.rt[i + 1] - tr.rt[i]) : 0;
                out.r[j].set(tr.rv[i * 4], tr.rv[i * 4 + 1], tr.rv[i * 4 + 2], tr.rv[i * 4 + 3]);
                if (i + 1 < tr.rt.length) {
                    Quaternionf q2 = new Quaternionf(tr.rv[i * 4 + 4], tr.rv[i * 4 + 5], tr.rv[i * 4 + 6], tr.rv[i * 4 + 7]);
                    out.r[j].slerp(q2, f);
                }
            }
            if (tr.pt != null) {
                int i = seg(tr.pt, tm);
                float f = i + 1 < tr.pt.length ? (tm - tr.pt[i]) / Math.max(1e-6f, tr.pt[i + 1] - tr.pt[i]) : 0;
                out.t[j].set(tr.pv[i * 3], tr.pv[i * 3 + 1], tr.pv[i * 3 + 2]);
                if (i + 1 < tr.pt.length) out.t[j].lerp(new Vector3f(tr.pv[i * 3 + 3], tr.pv[i * 3 + 4], tr.pv[i * 3 + 5]), f);
            }
        }
    }

    private static int seg(float[] times, float t) {
        int i = 0;
        while (i + 1 < times.length && times[i + 1] <= t) i++;
        return i;
    }

    public void blend(Pose a, Pose b, float w, Pose out) {
        for (int j = 0; j < jointCount; j++) {
            out.r[j].set(a.r[j]).slerp(b.r[j], w);
            out.t[j].set(a.t[j]).lerp(b.t[j], w);
        }
    }

    public Matrix4f worldOf(int joint) { return world[joint]; }

    /** Calcula el skinning y dibuja la malla. */
    public void render(Pose p, PoseStack.Pose stack, VertexConsumer vcons, int light, int overlay) {
        for (int j = 0; j < jointCount; j++) {
            Matrix4f w = world[j];
            if (parent[j] >= 0) w.set(world[parent[j]]); else w.identity();
            w.translate(p.t[j]).rotate(p.r[j]);
            skinM[j].set(w).mul(ibm[j]);
            skinM[j].get(skinArr, j * 16);
        }
        for (int v = 0; v < vc; v++) {
            float px = pos[v * 3], py = pos[v * 3 + 1], pz = pos[v * 3 + 2];
            float nx = nrm[v * 3], ny = nrm[v * 3 + 1], nz = nrm[v * 3 + 2];
            float ox = 0, oy = 0, oz = 0, onx = 0, ony = 0, onz = 0;
            for (int k = 0; k < 4; k++) {
                float wt = weights[v * 4 + k];
                if (wt <= 0f) continue;
                int o = joints[v * 4 + k] * 16;
                ox += wt * (skinArr[o] * px + skinArr[o + 4] * py + skinArr[o + 8] * pz + skinArr[o + 12]);
                oy += wt * (skinArr[o + 1] * px + skinArr[o + 5] * py + skinArr[o + 9] * pz + skinArr[o + 13]);
                oz += wt * (skinArr[o + 2] * px + skinArr[o + 6] * py + skinArr[o + 10] * pz + skinArr[o + 14]);
                onx += wt * (skinArr[o] * nx + skinArr[o + 4] * ny + skinArr[o + 8] * nz);
                ony += wt * (skinArr[o + 1] * nx + skinArr[o + 5] * ny + skinArr[o + 9] * nz);
                onz += wt * (skinArr[o + 2] * nx + skinArr[o + 6] * ny + skinArr[o + 10] * nz);
            }
            sp[v * 3] = ox; sp[v * 3 + 1] = oy; sp[v * 3 + 2] = oz;
            float len = (float) Math.sqrt(onx * onx + ony * ony + onz * onz);
            if (len < 1e-6f) len = 1f;
            sn[v * 3] = onx / len; sn[v * 3 + 1] = ony / len; sn[v * 3 + 2] = onz / len;
        }
        Matrix4f m = stack.pose(); Matrix3f n = stack.normal();
        for (int t = 0; t < ic; t += 3) {
            int a = idx[t], b = idx[t + 1], c = idx[t + 2];
            emit(vcons, m, n, a, light, overlay);
            emit(vcons, m, n, b, light, overlay);
            emit(vcons, m, n, c, light, overlay);
            emit(vcons, m, n, c, light, overlay); // el render type usa quads: 4o vertice repetido
        }
    }

    private void emit(VertexConsumer vcons, Matrix4f m, Matrix3f n, int v, int light, int overlay) {
        vcons.vertex(m, sp[v * 3], sp[v * 3 + 1], sp[v * 3 + 2])
                .color(255, 255, 255, 255)
                .uv(uv[v * 2], uv[v * 2 + 1])
                .overlayCoords(overlay)
                .uv2(light)
                .normal(n, sn[v * 3], sn[v * 3 + 1], sn[v * 3 + 2])
                .endVertex();
    }
}
