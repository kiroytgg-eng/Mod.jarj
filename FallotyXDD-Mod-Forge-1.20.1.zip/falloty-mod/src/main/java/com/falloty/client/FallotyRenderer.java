package com.falloty.client;

import com.falloty.entity.FallotyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class FallotyRenderer extends EntityRenderer<FallotyEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("falloty", "textures/entity/falloty.png");
    private static final float SCALE = 0.95F;

    public FallotyRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.4F;
    }

    @Override public ResourceLocation getTextureLocation(FallotyEntity e) { return TEXTURE; }

    private static void rotTo(FallotyModel m, FallotyModel.Pose p, String joint, float xDeg, float yDeg, float zDeg, float w) {
        if (w <= 0.001F) return;
        int j = m.joint(joint);
        org.joml.Quaternionf target = new org.joml.Quaternionf().rotationXYZ(xDeg * Mth.DEG_TO_RAD, yDeg * Mth.DEG_TO_RAD, zDeg * Mth.DEG_TO_RAD);
        p.r[j].slerp(target, Mth.clamp(w, 0F, 1F));
    }

    @Override
    public void render(FallotyEntity e, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        FallotyModel m = FallotyModel.get();
        if (m == null) { super.render(e, yaw, pt, ps, buf, light); return; }

        boolean sleeping = e.isSleeping();
        float age = e.tickCount + pt;
        float bodyYaw = Mth.rotLerp(pt, e.yBodyRotO, e.yBodyRot);
        float headYaw = Mth.rotLerp(pt, e.yHeadRotO, e.yHeadRot);
        float pitch = Mth.lerp(pt, e.xRotO, e.getXRot());

        /* ---------- animacion base: idle / caminar / correr ---------- */
        float dist = Mth.lerp(pt, e.animDistO, e.animDist);
        float moveB = Mth.lerp(pt, e.moveBlendO, e.moveBlend);
        float runB = Mth.lerp(pt, e.runBlendO, e.runBlend);
        float airB = Mth.lerp(pt, e.airBlendO, e.airBlend);
        float sitB = Mth.lerp(pt, e.sitBlendO, e.sitBlend);
        if (sleeping || sitB > 0.5F) moveB = 0F;
        if (sleeping) airB = 0F;
        float stride = Mth.lerp(runB, 1.1F, 1.9F);
        float u = (dist / stride) % 1F;
        if (u < 0) u += 1F;
        FallotyModel.Anim idle = m.anims.get("idle"), walk = m.anims.get("walk"), run = m.anims.get("run");
        m.sample("idle", age / 20F, m.idlePose);
        m.sample("walk", u * (walk != null ? walk.duration : 1F), m.walkPose);
        m.sample("run", u * (run != null ? run.duration : 0.6F), m.runPose);
        m.blend(m.walkPose, m.runPose, runB, m.mixA);
        m.blend(m.idlePose, m.mixA, moveB, m.finalPose);
        FallotyModel.Pose p = m.finalPose;

        /* ---------- salto / caida ---------- */
        float air = airB * (1F - sitB);
        rotTo(m, p, "upper_arm_l", -75, 0, 8, air); rotTo(m, p, "upper_arm_r", -75, 0, -8, air);
        rotTo(m, p, "forearm_l", -20, 0, 0, air);   rotTo(m, p, "forearm_r", -20, 0, 0, air);
        rotTo(m, p, "thigh_l", -40, 0, 0, air);     rotTo(m, p, "shin_l", 60, 0, 0, air);
        rotTo(m, p, "thigh_r", 12, 0, 0, air);      rotTo(m, p, "shin_r", 35, 0, 0, air);

        /* ---------- sentado ---------- */
        int hips = m.joint("hips");
        p.t[hips].y = Mth.lerp(sitB, p.t[hips].y, 0.17F);
        rotTo(m, p, "thigh_l", -82, 0, 0, sitB);  rotTo(m, p, "thigh_r", -82, 0, 0, sitB);
        rotTo(m, p, "shin_l", 8, 0, 0, sitB);     rotTo(m, p, "shin_r", 8, 0, 0, sitB);
        rotTo(m, p, "foot_l", -6, 0, 0, sitB);    rotTo(m, p, "foot_r", -6, 0, 0, sitB);
        rotTo(m, p, "upper_arm_l", -25, 0, 6, sitB); rotTo(m, p, "upper_arm_r", -25, 0, -6, sitB);

        /* ---------- comer ---------- */
        if (e.isUsingItem()) {
            float w = Mth.clamp(e.getTicksUsingItem() / 4F, 0F, 1F);
            float bob = Mth.sin(age * 1.6F) * 6F;
            rotTo(m, p, "upper_arm_r", -85 + bob, 0, -10, w);
            rotTo(m, p, "forearm_r", -75, 0, 0, w);
        }

        /* ---------- golpear / picar / construir ---------- */
        float sw = e.getAttackAnim(pt);
        if (sw > 0F && !sleeping) {
            float s = Mth.sin(sw * Mth.PI);
            p.r[m.joint("upper_arm_r")].rotateX(-1.9F * s);
            p.r[m.joint("forearm_r")].rotateX(-0.5F * s);
            p.r[m.joint("chest")].rotateY(0.35F * s);
        }

        /* ---------- mirar ---------- */
        if (!sleeping) {
            float d = Mth.clamp(Mth.wrapDegrees(headYaw - bodyYaw), -70F, 70F);
            float pc = Mth.clamp(pitch, -40F, 40F);
            p.r[m.joint("neck")].rotateY(-d * 0.5F * Mth.DEG_TO_RAD).rotateX(pc * 0.4F * Mth.DEG_TO_RAD);
            p.r[m.joint("head")].rotateY(-d * 0.5F * Mth.DEG_TO_RAD).rotateX(pc * 0.6F * Mth.DEG_TO_RAD);
        }

        /* ---------- colocar en el mundo ---------- */
        ps.pushPose();
        if (sleeping) {
            Direction bed = e.getBedOrientation();
            float beta = bed == null ? 0F : (float) Math.toDegrees(Math.atan2(-bed.getStepX(), -bed.getStepZ()));
            ps.mulPose(Axis.YP.rotationDegrees(beta));
            ps.translate(0.0F, 0.3F, 0.95F * SCALE);
            ps.mulPose(Axis.XP.rotationDegrees(-90F));
        } else {
            ps.mulPose(Axis.YP.rotationDegrees(-bodyYaw));
        }
        ps.scale(SCALE, SCALE, SCALE);

        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        int overlay = LivingEntityRenderer.getOverlayCoords(e, 0F);
        m.render(p, ps.last(), vc, light, overlay);

        /* ---------- objeto en la mano ---------- */
        ItemStack held = e.getMainHandItem();
        if (!held.isEmpty() && !sleeping) {
            ps.pushPose();
            ps.mulPoseMatrix(m.worldOf(m.joint("hand_r")));
            ps.mulPose(Axis.XP.rotationDegrees(180F));
            ps.translate(-0.0625F, 0.03F, -0.0625F);
            ps.mulPose(Axis.XP.rotationDegrees(-90F));
            ps.mulPose(Axis.YP.rotationDegrees(180F));
            Minecraft.getInstance().getItemRenderer().renderStatic(e, held, ItemDisplayContext.THIRD_PERSON_RIGHT_HAND, false,
                    ps, buf, e.level(), light, OverlayTexture.NO_OVERLAY, e.getId());
            ps.popPose();
        }
        ps.popPose();
        super.render(e, yaw, pt, ps, buf, light); // nombre sobre la cabeza + sombra
    }
}
