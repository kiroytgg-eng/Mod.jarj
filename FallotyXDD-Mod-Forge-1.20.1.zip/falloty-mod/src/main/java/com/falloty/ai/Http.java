package com.falloty.ai;

import com.falloty.FallotyMod;
import com.google.gson.*;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Llamadas HTTP a Groq (cerebro) y Fish Audio (voz). Se ejecutan fuera del hilo del servidor. */
public class Http {
    public static final ExecutorService POOL = Executors.newFixedThreadPool(3, r -> {
        Thread t = new Thread(r, "falloty-http"); t.setDaemon(true); return t;
    });
    private static final HttpClient CLIENT = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private static final Gson GSON = new Gson();

    /** Devuelve el texto (JSON) que contesta Groq, o null si falla. messages = lista de {role,content}. */
    public static String groqChat(String key, String model, List<String[]> messages) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("model", model);
            body.addProperty("temperature", 0.8);
            body.addProperty("max_tokens", 350);
            JsonObject fmt = new JsonObject(); fmt.addProperty("type", "json_object");
            body.add("response_format", fmt);
            JsonArray arr = new JsonArray();
            for (String[] m : messages) {
                JsonObject o = new JsonObject(); o.addProperty("role", m[0]); o.addProperty("content", m[1]); arr.add(o);
            }
            body.add("messages", arr);
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.groq.com/openai/v1/chat/completions"))
                    .timeout(Duration.ofSeconds(30))
                    .header("Authorization", "Bearer " + key)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body))).build();
            HttpResponse<String> res = CLIENT.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() != 200) {
                FallotyMod_log("Groq HTTP " + res.statusCode() + ": " + res.body());
                return null;
            }
            JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
            return json.getAsJsonArray("choices").get(0).getAsJsonObject()
                    .getAsJsonObject("message").get("content").getAsString();
        } catch (Exception e) {
            FallotyMod_log("Groq error: " + e);
            return null;
        }
    }

    /** Devuelve bytes WAV o null. */
    public static byte[] fishTts(String key, String model, String voiceId, String text) {
        try {
            JsonObject body = new JsonObject();
            body.addProperty("text", text);
            if (voiceId != null && !voiceId.isBlank()) body.addProperty("reference_id", voiceId.trim());
            body.addProperty("format", "wav");
            body.addProperty("sample_rate", 24000);
            body.addProperty("normalize", true);
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.fish.audio/v1/tts"))
                    .timeout(Duration.ofSeconds(40))
                    .header("Authorization", "Bearer " + key)
                    .header("Content-Type", "application/json")
                    .header("model", model)
                    .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body))).build();
            HttpResponse<byte[]> res = CLIENT.send(req, HttpResponse.BodyHandlers.ofByteArray());
            if (res.statusCode() != 200) {
                FallotyMod_log("Fish HTTP " + res.statusCode() + ": " + new String(res.body()));
                return null;
            }
            return res.body();
        } catch (Exception e) {
            FallotyMod_log("Fish error: " + e);
            return null;
        }
    }

    private static void FallotyMod_log(String s) {
        org.apache.logging.log4j.LogManager.getLogger(FallotyMod.MODID).warn(s);
    }
}
