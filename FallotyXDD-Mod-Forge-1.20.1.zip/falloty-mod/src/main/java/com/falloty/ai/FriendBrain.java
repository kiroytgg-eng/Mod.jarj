package com.falloty.ai;

import com.falloty.FallotyConfig;
import com.falloty.entity.FallotyEntity;
import com.falloty.net.FallotyNetwork;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;

/** El "cerebro": manda lo que pasa a Groq, recibe {say, action}, lo dice por chat y con voz (Fish Audio). */
public class FriendBrain {
    private static final String SYSTEM = """
            Eres FallotyXDD, un jugador de Minecraft amigo del jugador. Eres alegre, bromista, leal y te ENCANTA el chocolate.
            Hablas como un amigo en el chat: frases CORTAS (maximo 2), naturales, sin emojis. Responde en el mismo idioma que el jugador (por defecto espanol).
            Puedes hacer cosas en el mundo. Responde SIEMPRE solo con un JSON: {"say":"lo que dices","action":"accion"}.
            Acciones validas: none, follow (seguir), stay (quedarte quieto), come (ir hacia el jugador), mine (buscar y minar minerales),
            chop (talar arboles), build_house (construir una casa rapido y bonita), sleep (ir a dormir a una cama), wake (despertar),
            sit (sentarte), stand (levantarte), attack (atacar monstruos cercanos), give_items (darle lo que recogiste), stop (parar lo que haces).
            Usa "action" solo si el jugador te lo pide o es claramente lo que hay que hacer; si no, "none".
            Si te cuentan un [evento] del juego, reacciona en 1 frase con personalidad y action "none".
            Nunca digas que eres una IA. Nunca inventes que hiciste algo que no esta en tu estado.
            """;

    private final FallotyEntity e;
    private final ArrayDeque<String[]> history = new ArrayDeque<>();
    private volatile boolean busy = false;
    private long lastEventTick = -9999;

    public FriendBrain(FallotyEntity e) { this.e = e; }

    public void onPlayerMessage(ServerPlayer from, String text) {
        ask(from, "Jugador " + from.getGameProfile().getName() + " dice: " + text, from.getUUID().equals(e.getOwnerUUID()));
    }

    /** Evento del juego (termine la casa, encontre diamantes...). Limitado para no gastar API. */
    public void onEvent(String desc) {
        long now = e.level().getGameTime();
        if (now - lastEventTick < 300) return;
        lastEventTick = now;
        ask(null, "[evento] " + desc, false);
    }

    private void ask(ServerPlayer from, String userText, boolean mayAct) {
        if (!FallotyConfig.hasGroq()) return;
        if (busy) return;
        busy = true;
        final String key = FallotyConfig.GROQ_KEY.get();
        final String model = FallotyConfig.GROQ_MODEL.get();
        final String fishKey = FallotyConfig.FISH_KEY.get();
        final String voice = FallotyConfig.FISH_VOICE_ID.get();
        final String fishModel = FallotyConfig.FISH_MODEL.get();
        List<String[]> msgs = new ArrayList<>();
        msgs.add(new String[]{"system", SYSTEM + "\nESTADO ACTUAL: " + describeState()});
        msgs.addAll(history);
        msgs.add(new String[]{"user", userText});
        history.add(new String[]{"user", userText});
        while (history.size() > 14) history.poll();

        CompletableFuture.supplyAsync(() -> Http.groqChat(key, model, msgs), Http.POOL).thenAccept(resp -> {
            byte[] wav = null;
            String say = null, action = "none";
            if (resp != null) {
                try {
                    JsonObject o = JsonParser.parseString(resp).getAsJsonObject();
                    say = o.has("say") ? o.get("say").getAsString() : null;
                    action = o.has("action") ? o.get("action").getAsString() : "none";
                } catch (Exception ex) { say = resp; }
            }
            if (say != null && !say.isBlank() && !fishKey.isBlank()) {
                wav = Http.fishTts(fishKey, fishModel, voice, say);
            }
            final String fSay = say; final String fAct = action; final byte[] fWav = wav;
            e.getServer().execute(() -> {
                busy = false;
                if (fSay == null || fSay.isBlank() || !e.isAlive()) return;
                history.add(new String[]{"assistant", "{\"say\":\"" + fSay.replace("\"", "'") + "\",\"action\":\"" + fAct + "\"}"});
                while (history.size() > 14) history.poll();
                say(fSay);
                if (fWav != null) FallotyNetwork.sendVoice(e, fWav);
                if (mayAct) e.performAction(fAct.toLowerCase(Locale.ROOT).trim(), from);
            });
        }).exceptionally(ex -> { busy = false; return null; });
    }

    /** Escribe en el chat como si fuera otro jugador. */
    public void say(String text) {
        Component name = Component.literal("FallotyXDD");
        Component c = Component.translatable("chat.type.text", name, text);
        e.getServer().getPlayerList().broadcastSystemMessage(c, false);
    }

    public static void yellow(net.minecraft.server.MinecraftServer s, String text) {
        s.getPlayerList().broadcastSystemMessage(Component.literal(text).withStyle(ChatFormatting.YELLOW), false);
    }

    private String describeState() {
        StringBuilder sb = new StringBuilder();
        sb.append("vida ").append((int) e.getHealth()).append("/").append((int) e.getMaxHealth());
        sb.append(", modo ").append(e.getMode().name().toLowerCase());
        sb.append(e.isSitting() ? ", sentado" : "").append(e.isSleeping() ? ", durmiendo" : "");
        sb.append(", es ").append(e.level().isDay() ? "de dia" : "de noche");
        sb.append(", tiene casa: ").append(e.getHome() != null ? "si" : "no");
        int choc = 0, other = 0;
        for (int i = 0; i < e.inventory.getContainerSize(); i++) {
            ItemStack s = e.inventory.getItem(i);
            if (s.isEmpty()) continue;
            if (com.falloty.FallotyRegistry.isChocolate(s)) choc += s.getCount(); else other += s.getCount();
        }
        sb.append(", chocolates: ").append(choc).append(", otros items recogidos: ").append(other);
        net.minecraft.world.entity.player.Player o = e.getOwner();
        if (o != null) sb.append(", el jugador esta a ").append((int) e.distanceTo(o)).append(" bloques con vida ").append((int) o.getHealth());
        return sb.toString();
    }
}
