package com.falloty;

import net.minecraftforge.common.ForgeConfigSpec;

/** Archivo: config/falloty-common.toml  (tambien se puede cambiar con /falloty ...) */
public class FallotyConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.ConfigValue<String> GROQ_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> GROQ_MODEL;
    public static final ForgeConfigSpec.ConfigValue<String> FISH_KEY;
    public static final ForgeConfigSpec.ConfigValue<String> FISH_VOICE_ID;
    public static final ForgeConfigSpec.ConfigValue<String> FISH_MODEL;
    public static final ForgeConfigSpec.IntValue JOIN_DELAY_SECONDS;
    public static final ForgeConfigSpec.IntValue BUILD_BLOCKS_PER_TICK;
    public static final ForgeConfigSpec.BooleanValue ANSWER_ALL_CHAT;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("groq");
        GROQ_KEY = b.comment("OBLIGATORIO. API key de Groq (https://console.groq.com/keys). Sin ella FallotyXDD no entra a la partida.")
                .define("api_key", "");
        GROQ_MODEL = b.comment("Modelo de Groq que usa como cerebro").define("model", "llama-3.3-70b-versatile");
        b.pop();
        b.push("fish_audio");
        FISH_KEY = b.comment("API key de Fish Audio (https://fish.audio/app/api-keys). Da voz a FallotyXDD. Sin ella solo habla por chat.")
                .define("api_key", "");
        FISH_VOICE_ID = b.comment("ID del modelo de voz (reference_id) de Fish Audio. Vacio = voz por defecto.")
                .define("voice_reference_id", "");
        FISH_MODEL = b.comment("Modelo TTS de Fish Audio (header 'model')").define("tts_model", "s2-pro");
        b.pop();
        b.push("amigo");
        JOIN_DELAY_SECONDS = b.comment("Segundos que tarda en unirse despues de que entras")
                .defineInRange("join_delay_seconds", 6, 1, 600);
        BUILD_BLOCKS_PER_TICK = b.comment("Bloques que coloca por tick al construir la casa")
                .defineInRange("build_blocks_per_tick", 14, 1, 100);
        ANSWER_ALL_CHAT = b.comment("true = responde a todo lo que escribes si estas cerca; false = solo si dices su nombre")
                .define("answer_all_chat", true);
        b.pop();
        SPEC = b.build();
    }

    public static boolean hasGroq() { return !GROQ_KEY.get().isBlank(); }
    public static boolean hasFish() { return !FISH_KEY.get().isBlank(); }
}
