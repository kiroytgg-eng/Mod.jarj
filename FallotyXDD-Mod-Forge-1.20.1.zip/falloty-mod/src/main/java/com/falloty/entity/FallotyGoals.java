package com.falloty.entity;

import com.falloty.FallotyConfig;
import com.falloty.FallotyRegistry;
import com.falloty.build.HouseBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;

import java.util.*;

public class FallotyGoals {

    /* ============ seguir al jugador ============ */
    public static class FollowOwnerGoal extends Goal {
        private final FallotyEntity e; private int recalc;
        public FollowOwnerGoal(FallotyEntity e) { this.e = e; setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() {
            Player o = e.getOwner();
            return e.getMode() == FallotyEntity.Mode.FOLLOW && !e.isSitting() && o != null && !o.isSpectator() && e.distanceToSqr(o) > 36;
        }
        @Override public boolean canContinueToUse() {
            Player o = e.getOwner();
            return e.getMode() == FallotyEntity.Mode.FOLLOW && !e.isSitting() && o != null && e.distanceToSqr(o) > 9;
        }
        @Override public void start() { recalc = 0; }
        @Override public void stop() { e.getNavigation().stop(); }
        @Override public void tick() {
            Player o = e.getOwner();
            if (o == null) return;
            e.getLookControl().setLookAt(o, 10.0F, e.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                e.getNavigation().moveTo(o, e.distanceToSqr(o) > 100 ? 1.35D : 1.0D);
            }
        }
    }

    /* ============ defender al jugador ============ */
    public static class DefendOwnerGoal extends TargetGoal {
        private final FallotyEntity e; private LivingEntity victim; private int tsHurtBy, tsHurt;
        public DefendOwnerGoal(FallotyEntity e) { super(e, false); this.e = e; setFlags(EnumSet.of(Flag.TARGET)); }
        @Override public boolean canUse() {
            Player o = e.getOwner();
            if (o == null || e.isSitting() || e.isSleeping()) return false;
            LivingEntity a = o.getLastHurtByMob();
            int t = o.getLastHurtByMobTimestamp();
            if (a != null && t != tsHurtBy && a instanceof Enemy && canAttack(a, TargetingConditions.DEFAULT)) { victim = a; tsHurtBy = t; return true; }
            a = o.getLastHurtMob();
            t = o.getLastHurtMobTimestamp();
            if (a != null && t != tsHurt && a instanceof Enemy && canAttack(a, TargetingConditions.DEFAULT)) { victim = a; tsHurt = t; return true; }
            return false;
        }
        @Override public void start() { e.setTarget(victim); super.start(); }
    }

    /* ============ comer chocolate ============ */
    public static class EatChocolateGoal extends Goal {
        private final FallotyEntity e; private boolean eating; private int cooldown;
        public EatChocolateGoal(FallotyEntity e) { this.e = e; }
        @Override public boolean canUse() {
            if (cooldown > 0) { cooldown--; return false; }
            if (e.isUsingItem() || e.isSleeping() || e.isSitting() || !e.hasChocolate()) return false;
            return e.getHealth() <= e.getMaxHealth() - 5 || e.getRandom().nextInt(2400) == 0;
        }
        @Override public boolean canContinueToUse() { return eating && e.isUsingItem(); }
        @Override public void start() {
            ItemStack bar = e.takeChocolateBar();
            if (bar.isEmpty()) { eating = false; return; }
            e.setItemSlot(EquipmentSlot.MAINHAND, bar);
            e.startUsingItem(InteractionHand.MAIN_HAND);
            eating = true;
        }
        @Override public void stop() {
            if (!eating) return;
            eating = false;
            cooldown = 200;
            if (e.getMainHandItem().isEmpty()) { // se lo termino
                e.heal(6.0F);
                if (e.level() instanceof ServerLevel sl)
                    sl.sendParticles(ParticleTypes.HEART, e.getX(), e.getY() + 1.9, e.getZ(), 5, 0.3, 0.3, 0.3, 0.02);
                e.brain.onEvent("te acabas de comer un chocolate, ¡que rico!");
            } else {
                e.stopUsingItem();
            }
            e.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            e.refreshTool();
        }
    }

    /* ============ dormir en cama ============ */
    public static class SleepInBedGoal extends Goal {
        private final FallotyEntity e; private BlockPos bed; private int timeout, repath;
        public SleepInBedGoal(FallotyEntity e) { this.e = e; setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP, Flag.LOOK)); }
        private boolean wants() {
            Player o = e.getOwner();
            return e.getMode() == FallotyEntity.Mode.SLEEP || (o != null && o.isSleeping());
        }
        @Override public boolean canUse() {
            if (e.isSleeping() || e.getTarget() != null || !wants()) return false;
            bed = e.findFreeBed(24);
            return bed != null;
        }
        @Override public boolean canContinueToUse() { return !e.isSleeping() && timeout > 0 && wants() && e.getTarget() == null; }
        @Override public void start() { timeout = 600; repath = 0; }
        @Override public void tick() {
            timeout--;
            if (bed == null) return;
            Vec3 c = Vec3.atCenterOf(bed);
            if (e.distanceToSqr(c) < 6.0D) { e.trySleep(bed); return; }
            if (--repath <= 0) { repath = 20; e.getNavigation().moveTo(c.x, bed.getY(), c.z, 1.1D); }
        }
    }

    /* ============ minar minerales ============ */
    public static class MineOreGoal extends Goal {
        private final FallotyEntity e;
        private BlockPos target; private int scanCd, repath, stuck; private Vec3 lastPos = Vec3.ZERO;
        private final Set<Long> bad = new HashSet<>();
        public MineOreGoal(FallotyEntity e) { this.e = e; setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP)); }
        @Override public boolean canUse() { return e.getMode() == FallotyEntity.Mode.MINE && !e.isSitting() && !e.isSleeping(); }
        @Override public void start() { target = null; bad.clear(); scanCd = 0; }
        @Override public void stop() { target = null; e.resetBreak(); }

        private boolean isOre(BlockPos p) { return e.level().getBlockState(p).is(Tags.Blocks.ORES); }

        private BlockPos findOre() {
            BlockPos c = e.blockPosition(); BlockPos best = null; double bd = Double.MAX_VALUE;
            int r = 24;
            for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
                if (!e.level().hasChunkAt(c.offset(dx, 0, dz))) continue;
                for (int dy = -14; dy <= 12; dy++) {
                    BlockPos p = c.offset(dx, dy, dz);
                    if (p.getY() < e.level().getMinBuildHeight() || bad.contains(p.asLong())) continue;
                    if (!isOre(p)) continue;
                    double d = dx * dx + dz * dz + dy * dy * 2.0;
                    if (d < bd) { bd = d; best = p; }
                }
            }
            return best;
        }

        @Override public void tick() {
            if (e.tickCount - e.sessionStart > 7000 || e.minedCount >= 48) {
                e.finishSession("terminaste de minar, juntaste " + e.minedCount + " minerales"); return;
            }
            if (target == null || !isOre(target)) {
                target = null; e.resetBreak();
                if (--scanCd > 0) return;
                scanCd = 20;
                target = findOre();
                if (target == null) { e.finishSession(e.minedCount > 0 ? "ya no ves mas minerales cerca, minaste " + e.minedCount : "no encontraste minerales cerca"); return; }
                String name = e.level().getBlockState(target).getBlock().getName().getString();
                if (name.toLowerCase().contains("diamond") || name.toLowerCase().contains("netherite") || name.toLowerCase().contains("ancient") || name.toLowerCase().contains("diamante"))
                    e.brain.onEvent("encontraste un mineral valioso: " + name);
            }
            Vec3 eye = e.getEyePosition(); Vec3 c = Vec3.atCenterOf(target);
            double d = eye.distanceTo(c);
            if (d <= 4.2D) {
                BlockHitResult hit = e.level().clip(new ClipContext(eye, c, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
                BlockPos bp = hit.getType() == HitResult.Type.BLOCK ? hit.getBlockPos() : target;
                if (!e.safeToBreak(bp, bp.equals(target))) { bad.add(target.asLong()); target = null; return; }
                e.getNavigation().stop();
                if (e.breakBlockStep(bp) && bp.equals(target)) { e.minedCount++; target = null; stuck = 0; }
                return;
            }
            // acercarse
            if (--repath <= 0) {
                repath = 15;
                boolean ok = e.getNavigation().moveTo(c.x, c.y, c.z, 1.15D);
                Vec3 now = e.position();
                if (!ok || (e.getNavigation().isDone() && now.distanceToSqr(lastPos) < 0.5D)) stuck += 15; else stuck = Math.max(0, stuck - 15);
                lastPos = now;
            }
            if (stuck >= 30) { // no hay camino: cavar un tunel hacia el mineral
                Vec3 dir = c.subtract(eye).normalize();
                BlockPos bp = firstSolid(eye, dir, 3.5D);
                if (bp == null) bp = firstSolid(e.position().add(0, 0.5, 0), dir, 3.5D);
                if (bp != null) {
                    if (!e.safeToBreak(bp, false)) { bad.add(target.asLong()); target = null; stuck = 0; return; }
                    e.getNavigation().stop();
                    e.getMoveControl().setWantedPosition(c.x, c.y, c.z, 0.0D);
                    if (e.breakBlockStep(bp)) stuck = 20;
                } else {
                    e.getMoveControl().setWantedPosition(c.x, c.y, c.z, 1.0D);
                    stuck = 0;
                }
            }
        }

        private BlockPos firstSolid(Vec3 from, Vec3 dir, double len) {
            BlockHitResult hit = e.level().clip(new ClipContext(from, from.add(dir.scale(len)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
            return hit.getType() == HitResult.Type.BLOCK ? hit.getBlockPos() : null;
        }
    }

    /* ============ talar arboles ============ */
    public static class ChopTreeGoal extends Goal {
        private final FallotyEntity e;
        private final List<BlockPos> logs = new ArrayList<>();
        private final Set<Long> bad = new HashSet<>();
        private BlockPos base; private boolean timber; private int scanCd, repath, trees, stuckTicks;
        public ChopTreeGoal(FallotyEntity e) { this.e = e; setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP)); }
        @Override public boolean canUse() { return e.getMode() == FallotyEntity.Mode.CHOP && !e.isSitting() && !e.isSleeping(); }
        @Override public void start() { logs.clear(); bad.clear(); timber = false; trees = 0; scanCd = 0; stuckTicks = 0; }
        @Override public void stop() { e.resetBreak(); }

        private boolean findTree() {
            BlockPos c = e.blockPosition(); BlockPos best = null; double bd = Double.MAX_VALUE;
            for (int dx = -24; dx <= 24; dx++) for (int dz = -24; dz <= 24; dz++) {
                if (!e.level().hasChunkAt(c.offset(dx, 0, dz))) continue;
                for (int dy = -6; dy <= 10; dy++) {
                    BlockPos p = c.offset(dx, dy, dz);
                    if (bad.contains(p.asLong()) || !e.level().getBlockState(p).is(BlockTags.LOGS)) continue;
                    double d = dx * dx + dz * dz + dy * dy;
                    if (d < bd) { bd = d; best = p; }
                }
            }
            if (best == null) return false;
            // juntar el arbol (troncos conectados)
            List<BlockPos> group = new ArrayList<>(); Deque<BlockPos> q = new ArrayDeque<>(); Set<Long> seen = new HashSet<>();
            q.add(best); seen.add(best.asLong());
            while (!q.isEmpty() && group.size() < 160) {
                BlockPos p = q.poll(); group.add(p);
                for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                    BlockPos n = p.offset(dx, dy, dz);
                    if (Math.abs(n.getX() - best.getX()) > 6 || Math.abs(n.getZ() - best.getZ()) > 6 || n.getY() > best.getY() + 40) continue;
                    if (seen.add(n.asLong()) && e.level().getBlockState(n).is(BlockTags.LOGS)) q.add(n);
                }
            }
            group.sort(Comparator.comparingInt(BlockPos::getY));
            BlockPos top = group.get(group.size() - 1);
            int leaves = 0;
            for (int dx = -3; dx <= 3; dx++) for (int dy = -3; dy <= 3; dy++) for (int dz = -3; dz <= 3; dz++)
                if (e.level().getBlockState(top.offset(dx, dy, dz)).is(BlockTags.LEAVES)) leaves++;
            if (leaves < 5) { for (BlockPos p : group) bad.add(p.asLong()); return true; } // no es un arbol natural
            logs.clear(); logs.addAll(group); base = group.get(0); timber = false; stuckTicks = 0;
            return true;
        }

        @Override public void tick() {
            if (e.tickCount - e.sessionStart > 7000) { e.finishSession("terminaste de talar, cortaste " + trees + " arboles"); return; }
            if (logs.isEmpty()) {
                if (--scanCd > 0) return;
                scanCd = 10;
                if (!findTree()) { e.finishSession(trees > 0 ? "talaste " + trees + " arboles y ya no ves mas" : "no encontraste arboles cerca"); }
                return;
            }
            ServerLevel lv = (ServerLevel) e.level();
            if (!timber) {
                BlockPos first = logs.get(0);
                if (!lv.getBlockState(first).is(BlockTags.LOGS)) { logs.remove(0); return; }
                double d = e.getEyePosition().distanceTo(Vec3.atCenterOf(first));
                if (d > 4.0D) {
                    if (--repath <= 0) { repath = 15; e.getNavigation().moveTo(first.getX() + 0.5, first.getY(), first.getZ() + 0.5, 1.15D); }
                    if (++stuckTicks > 300) { bad.add(first.asLong()); logs.clear(); stuckTicks = 0; }
                } else {
                    e.getNavigation().stop();
                    if (e.breakBlockStep(first)) { logs.remove(0); timber = true; }
                }
            } else {
                for (int i = 0; i < 2 && !logs.isEmpty(); i++) {
                    BlockPos p = logs.remove(0);
                    BlockState s = lv.getBlockState(p);
                    if (s.is(BlockTags.LOGS)) {
                        e.collectDrops(lv, p, s);
                        lv.destroyBlock(p, false, e);
                    }
                }
                e.getLookControl().setLookAt(Vec3.atCenterOf(base.above(3)));
                if (e.tickCount % 3 == 0) e.swing(InteractionHand.MAIN_HAND);
                if (logs.isEmpty()) {
                    timber = false; trees++; e.choppedCount++;
                    if (trees >= 3) e.finishSession("terminaste de talar 3 arboles, ya tienes madera");
                }
            }
        }
    }

    /* ============ construir casa ============ */
    public static class BuildHouseGoal extends Goal {
        private final FallotyEntity e; private HouseBuilder.Plan plan; private int idx; private boolean cleared;
        public BuildHouseGoal(FallotyEntity e) { this.e = e; setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP)); }
        @Override public boolean canUse() {
            if (e.getMode() != FallotyEntity.Mode.BUILD || e.isSitting() || e.isSleeping()) { plan = null; return false; }
            if (plan == null) {
                Player o = e.getOwner();
                if (o == null || !(e.level() instanceof ServerLevel sl)) { e.setMode(FallotyEntity.Mode.FOLLOW); return false; }
                plan = HouseBuilder.plan(sl, o);
                idx = 0; cleared = false;
                if (plan == null) {
                    e.setMode(FallotyEntity.Mode.FOLLOW);
                    e.brain.onEvent("no encontraste un terreno plano y libre en el Overworld para construir la casa");
                    return false;
                }
            }
            return true;
        }
        @Override public void stop() { e.resetBreak(); }
        @Override public void tick() {
            ServerLevel lv = (ServerLevel) e.level();
            Vec3 c = Vec3.atCenterOf(plan.center);
            if (e.position().distanceToSqr(c) > 14 * 14) {
                if (e.tickCount % 15 == 0) e.getNavigation().moveTo(c.x, c.y, c.z, 1.4D);
                return;
            }
            e.getNavigation().stop();
            e.getLookControl().setLookAt(c.x, c.y + 2, c.z);
            if (!cleared) { plan.clear(lv); cleared = true; }
            int per = FallotyConfig.BUILD_BLOCKS_PER_TICK.get();
            for (int i = 0; i < per && idx < plan.blocks.size(); i++) plan.place(lv, idx++);
            if (e.tickCount % 4 == 0) {
                e.swing(InteractionHand.MAIN_HAND);
                lv.playSound(null, e.blockPosition(), SoundEvents.WOOD_PLACE, SoundSource.BLOCKS, 0.8F, 0.9F + e.getRandom().nextFloat() * 0.3F);
            }
            if (idx >= plan.blocks.size()) {
                plan.finish(lv);
                e.setHome(plan.door);
                plan = null;
                e.setMode(FallotyEntity.Mode.FOLLOW);
                e.brain.onEvent("acabas de terminar de construir una casa bonita para el jugador, con camas, cofre y mesa");
            }
        }
    }
}
